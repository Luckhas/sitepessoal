import React from 'react';
import './styles.css';

export const Portfolio = () => {
    return(
        <div className="portolfioItem">
            <div>
                <img src="https://picsum.photos/id/217/1000" alt=""/>
            </div>
            <div className="portfolioDescription">
                <h1>Titulo</h1>
                <p>Descrição: Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tempore, ab.</p>
            </div>
        </div>
    );
}