import React from 'react';
import { Footer as Footerr } from './styles';
import './styles.css';

function Footer() {
    return (
        <Footerr/>
    );
}

export default Footer;