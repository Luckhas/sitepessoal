import styled from 'styled-components';
import { Button } from 'react-bootstrap';

export const Root = styled.div`
    padding: 0;
    margin: 0;
`;